package com.kh.spring.board.model.service;

public class BoardServiceImpl {

}

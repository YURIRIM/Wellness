package com.kh.spring.photoBulletin.model.service;

public interface PhotoBulletinService {

}

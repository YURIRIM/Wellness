package com.kh.spring.photoBulletin.model.dao;

import org.springframework.stereotype.Repository;

@Repository
public class PhotoBulletinDao {
	
	//sqlSession 객체 객체 받아와서 mapper 에 접근해서 필요한 sql 구문 받아오기
}

package com.kh.spring.answerqna.model.vo;

public class Answerqna {

}

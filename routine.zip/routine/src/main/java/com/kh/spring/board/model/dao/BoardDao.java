package com.kh.spring.board.model.dao;

public class BoardDao {

}

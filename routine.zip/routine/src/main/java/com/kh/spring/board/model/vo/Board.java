package com.kh.spring.board.model.vo;

public class Board {
	
}

package com.kh.spring.userqna.model.service;

public class UserqnaServiceImpl {

}

package com.kh.spring.openForum.model.service;

public interface OpenForumService {

}

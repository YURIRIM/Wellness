package com.kh.spring.userqna.model.dao;

public class UserqnaDao {

}

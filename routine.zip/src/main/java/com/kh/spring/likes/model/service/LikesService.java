package com.kh.spring.likes.model.service;

public interface LikesService {

}

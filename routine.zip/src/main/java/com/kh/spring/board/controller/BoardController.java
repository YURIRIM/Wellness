package com.kh.spring.board.controller;

public class BoardController {

}

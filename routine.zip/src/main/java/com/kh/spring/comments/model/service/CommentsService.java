package com.kh.spring.comments.model.service;

public interface CommentsService {

}

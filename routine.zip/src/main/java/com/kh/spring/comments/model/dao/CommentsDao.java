package com.kh.spring.comments.model.dao;

import org.springframework.stereotype.Repository;

@Repository
public class CommentsDao {

}

package com.kh.spring.userqna.model.vo;

public class Userqna {

}

package com.kh.spring.answerqna.model.service;

public class AnswerqnaService {

}

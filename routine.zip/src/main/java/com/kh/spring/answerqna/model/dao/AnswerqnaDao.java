package com.kh.spring.answerqna.model.dao;

public class AnswerqnaDao {

}
